package pes.ooad.airbnb.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import pes.ooad.airbnb.model.User;
import pes.ooad.airbnb.repository.UserRepository;
import pes.ooad.airbnb.util.Helpers;

@Controller
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:8080", maxAge = 3600)
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody String email, String phone) throws JsonProcessingException{
        if(email.length()>0 && userRepository.findByEmail(email).isPresent() && ){
            return ResponseEntity.ok().body("");
        }
//        else if()
        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("{}");
        return ResponseEntity.ok().body("");
    }


    @PostMapping("/register")
    public ResponseEntity<String> addNewUser(@RequestBody User user) throws JsonProcessingException {
        if(userRepository.findByEmail(user.getEmail()).isPresent() || userRepository.findByPhone(user.getPhone()).isPresent())
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("{}");
        User savedUser = userRepository.save(user);
        return ResponseEntity.ok().body(Helpers.convertToJson(userRepository.save(user)));
    }
}
